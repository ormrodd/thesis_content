# Generates a 
#
# Generates a person object
# 
#
import random
import uuid
import json





def people_generator ():
	person = {}

	return person



typ = ["workstation", "server", "administrator"]

max_nodes = 40
max_internet_nodes = 40
max_links = 40

nodes = []
links = []

node_ip_map = {}

for ip_4_in in range(max_nodes):

	ip_3 = ip_4_in / 254
	ip_4 = ip_4_in % 254

	#print ip_3
	#print ip_4

	#print random.randint(1,11)

	site = random.randint(1,3)
#	print site

	role = typ[random.randint(0,2)]
#	print role

	ip = [172, 10, 1+ip_3, ip_4]
#	print ip

	f = file("/usr/share/dict/words","r")
	subhost = random.choice(f.readlines()).strip()
#	print subhost.upper()

	uid = uuid.uuid4() 
#	print uid

	node = {}
	node ["_id"]  = {"$oid": str(uid)}
	node ["site"] = site
	node ["hostname"] = subhost.upper() + ".BIGMKT1.COM"
	node ["role"] = role 
	node ["ip"] = str(ip[0]) + "." + str(ip[1]) + "." + str(ip[2]) + "." + str(ip[3])

	node_ip_map[str(ip[0]) + "." + str(ip[1]) + "." + str(ip[2]) + "." + str(ip[3])] = True

#	print node
	nodes.append(node)
#print nodes







for ip_4_in in range(max_nodes):

	ip_3 = ip_4_in / 254
	ip_4 = ip_4_in % 254

	ip = [10, random.randint(0,250), 1+ip_3, ip_4]
#	print ip

#	f = file("/usr/share/dict/words","r")
#	subhost = random.choice(f.readlines()).strip()
#	print subhost.upper()

#	uid = uuid.uuid4() 
#	print uid

	node = {}
#	node ["_id"]  = {"$oid": str(uid)}
	node ["ip"] = str(ip[0]) + "." + str(ip[1]) + "." + str(ip[2]) + "." + str(ip[3])

	node_ip_map[str(ip[0]) + "." + str(ip[1]) + "." + str(ip[2]) + "." + str(ip[3])] = True
#	print node
	nodes.append(node)


for link_in in range(max_links):
	source = random.choice(node_ip_map.keys())
#	print source

	target = random.choice(node_ip_map.keys())
#	print target

	if source != target:
		links.append({"source": source, "target":target, "nf": [], "value":1})

total = {"nodes": nodes, "links":links}
#print nodes
#print links
print json.dumps(total)





